for i in range(1, 11):
    print(f"\n{i}")
    for j in range(1, 11):
        print(f"{i} * {j} = {i * j}")