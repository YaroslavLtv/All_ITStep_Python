user_number_1 = int(input("Enter first number: "))
user_number_2 = int(input("Enter second number: "))

# if user_number_1 > user_number_2:
#     print(f"The smallest number is {user_number_2}")
# elif user_number_1 < user_number_2:
#     print(f"The smallest number is {user_number_1}")
# elif user_number_1 == user_number_2:
#     print(f"The numbers is equals")

if user_number_1 > user_number_2:
    print(f"The smallest number is {user_number_2}")
elif user_number_1 == user_number_2:
    print(f"The numbers is equals")
else:
    print(f"The smallest number is {user_number_1}")


