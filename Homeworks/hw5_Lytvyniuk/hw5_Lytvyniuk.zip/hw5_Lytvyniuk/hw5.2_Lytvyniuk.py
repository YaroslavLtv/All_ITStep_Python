user_number = int(input("Enter number: "))

if user_number > 0:
    print(f"Value of sign(x) = 1")
elif user_number < 0:
    print(f"Value of sign(x) = -1")
elif user_number == 0:
    print(f"Value of sign(x) = 0")
